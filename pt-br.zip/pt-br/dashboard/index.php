<?php

return [
    'search' => 'Pesquisar servidores ...',
    'no_matches' => 'Não foram encontrados servidores que correspondam aos critérios de pesquisa fornecidos.',
    'cpu_title' => 'CPU',
    'memory_title' => 'Memory',
];
