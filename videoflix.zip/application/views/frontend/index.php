<?php
$selected_theme = 'flixer';
include $selected_theme . '/index.php';
?>