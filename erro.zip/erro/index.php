<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>HTML</title>
  
  <!-- HTML -->
  

  <!-- Custom Styles -->
  <link rel="stylesheet" href="style.css">
</head>

<body>
  
  
  
  
  
  
  
  <div class="erro">
    <div class="erro-2">
      
    </div>
    <a class="text-erro">Estamos Em Manutenção</a>
    <br>
    <a class="text-erro">Voltamos em Breve!</a>
    
  </div>
  
</body>
</html>
