<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NetCut</title>
  <link rel="stylesheet" href="b-1.css">
</head>










<body>
  
  <!-Começo->
  <div class="b877">
    
    <div class="pt-20">
    </div>
    
    
    
    
    
    
    <div class="pt-21">
      <a class="text-2233">Ativação da sua Conta</a>
    </div>
    
    <br>
    <br>
    
    
     
     
    <div class="pt-22">
       <img class="img-125" src="	<?php echo base_url();?>assets/global/thumb1.png
							" alt="">
    </div>
    
    <br>
    <br>
    
    <div class="pt-23">
      
      <a class="text-444">Olá</a>
      <br>
      <br>
      <a class="text-4444">Seja Bem-vindo!</a>
      
    </div>
    
    

<br>
<br>
<br>
    
    
    <div class="bh-1">
      
      
      
   <form method="post" action="<?php echo base_url();?>index.php?payment/stripe_payment/<?php echo 1;?>">
            
            <label>
                <div id="card-element" class="field is-empty"></div>
                
               
            </label>
            <button class="by-1" type="submit">
                ATIVAR AGORA! 
            </button>
            <div class="outcome">
                <div class="error" role="alert"></div>
                <div class="success"><span class="token"></span>
                </div>
            </div>
            <input type="hidden" name="stripeToken" value="">
        </form>
    </div>
    
    
  </div>
   <!-Fim->

</body>








</html>
