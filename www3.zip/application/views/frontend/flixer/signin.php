<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Login - NetCut</title>
  

  <!-- Custom Styles -->
  <link rel="stylesheet" href="login.css">
</head>






<body>
  
  
  <!-Começo->
  <div class="b77">
  
  <div class="b44">
  </div>
  
  <div class="b55">
    
    <a class="net-1">NetCut</a>
    <br>
    <a class="net-2">login</a>
    
  </div>
  <br>
  <br>
  
  <div class="b774">
    
    
    
    
    
    
    
    
    
    
    <div class="b125">
      
      
      <div class="b666">
        
      </div>
      
      
      	<form method="post" action="<?php echo base_url();?>index.php?home/signin">
      	  
      	  
					<div class="b-text">
						<input class="b-text-1" type="email"  name="email" placeholder=" E-mail" required/>
					</div>
					
					<br>
					
					<div class="b-text">
						<input class="b-text-1" type="password" name="password" placeholder=" Password" required/>
					</div>
					
					
					<div class="btt-1">
					  
					</div>
					
					<button class="btt-2"> Entrar </button>
					
					
					
					
					
				</form>
      
      
     <br>
      <br>
      <div>
        <a class="n1-1" link href="https://api.whatsapp.com/send/?phone=5564981160693">Não tenho uma conta!</a>
      </div>
      
      
    </div>
    
    
    
    
    
    
    
  </div>
  </div>
  
  
  
  <!-Fim->
  
  
  
  
  
  
</body>









</html>
